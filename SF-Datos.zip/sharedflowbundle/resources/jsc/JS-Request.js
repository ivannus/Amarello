var proxy_pathsuffix = context.getVariable('proxy.pathsuffix');
var request_verb = context.getVariable('request.verb');
var messageid = context.getVariable("messageid");
var app_id = context.getVariable('verifyapikey.VK-Verficar-Consumer-Key.developer.app.name');

var json_content = "";

var idEmpleado = "";

try {
    if (!proxy_pathsuffix.match("\/empleados\/.*") && request_verb != "GET") {
        json_content = JSON.parse(context.getVariable('request.content'));
    } else if (proxy_pathsuffix.match("\/empleados\/.*") && request_verb == "PUT") {
        json_content = JSON.parse(context.getVariable('request.content'));
    }
} catch (err) {
    proxy_pathsuffix = "";
    errorBody(err);
}

var bodyRequest;
var url = "";
var content_type = 'application/x-www-form-urlencoded';

if (proxy_pathsuffix == "/empleados" && request_verb == "POST") {
	content_type = "application/json";
    requestCrearEmpleado();
} else if (proxy_pathsuffix.match("\/empleados\/.*") && request_verb == "GET") {
    content_type = "application/json";

    var path_id_var_arr = proxy_pathsuffix.split("/");
    var path_id_var = "";

    if(path_id_var_arr[2] != undefined) {
        path_id_var = path_id_var_arr[2].trim();
    } else if(path_id_var == ""){
		error400();
	}
	
	if(path_id_var == 1){
        bodyResponse200BusquedaExitosa();
    } else{
		error404();
	}
} else if (proxy_pathsuffix.match("\/empleados\/.*") && request_verb == "PUT") {
    content_type = "application/json";

    var path_id_var_arr = proxy_pathsuffix.split("/");
    var path_id_var = "";

    if(path_id_var_arr[2] != undefined) {
        path_id_var = path_id_var_arr[2].trim();
    } else if(path_id_var == ""){
		error400();
	}
	
	if(path_id_var == 1){
        bodyResponse201ActualizacionExitosa();
    } else{
		error404();
	}

} else if (proxy_pathsuffix.match("\/empleados\/.*") && request_verb == "DELETE") {
   
    content_type = "application/json";

    var path_id_var_arr = proxy_pathsuffix.split("/");
    var path_id_var = "";

    if(path_id_var_arr[2] != undefined) {
        path_id_var = path_id_var_arr[2].trim();
    } else if(path_id_var == ""){
		error400();
	}
	
	if(path_id_var == 1){
        bodyResponse200EliminacionExitosa();
    } else{
		error404();
	}
	
}

function requestCrearEmpleado(){
	
	idEmpleado = getRandomIntInclusive(1,20);
	
	bodyResponse201CreacionExitosa(idEmpleado);
		
}

function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1) + min);
}

function bodyResponse201CreacionExitosa(idParam) {
    context.setVariable('message.status.code', '201');
    context.setVariable('message.reason.phrase', 'ÉXITO');
    context.setVariable('request.formparam.idEmpleado', idParam);
	
    bodyResponse = {
        mensaje: "Creacion Exitosa",
		folio: messageid,
        resultado: {
			idEmpleado: idParam
		}
    }
	context.setVariable("response.content", JSON.stringify(bodyResponse));
}

function bodyResponse200BusquedaExitosa() {
	
    bodyResponse = {
        mensaje: "Busqueda Exitosa",
		folio: messageid,
        resultado: {
			candidato: {
				nombreCompleto: "Iván Sánchez Coroona",
				edad: 34,
				fechaNacimiento: "23/08/1988",
			}
		}
    }
	context.setVariable("response.content", JSON.stringify(bodyResponse));
}

function bodyResponse201ActualizacionExitosa(idParam) {
    context.setVariable('message.status.code', '201');
    context.setVariable('message.reason.phrase', 'ÉXITO');
    context.setVariable('request.formparam.idEmpleado', idParam);
	
    bodyResponse = {
        mensaje: "Actualizacion Exitosa",
		folio: messageid,
        resultado: {
			idEmpleado: idParam
		}
    }
	context.setVariable("response.content", JSON.stringify(bodyResponse));
}

function bodyResponse200EliminacionExitosa() {
	
    bodyResponse = {
        mensaje: "Eliminacion Exitosa",
		folio: messageid,
    }
	context.setVariable("response.content", JSON.stringify(bodyResponse));
}

function error400() {
    bodyResponse = {
        codigo: "400.isc-aml-gestion-empleados.4000",
		mensaje: "Peticion invalida",
		folio: messageid,
		info: "https://dev-api.com/info#400.isc-aml-gestion-empleados.4000",
        detalles: [
			"Parametros incorrectos"
		]
    }
	context.setVariable("response.content", JSON.stringify(bodyResponse));
}

function error404() {
    bodyResponse = {
        codigo: "404.isc-aml-gestion-empleados.4004",
		mensaje: "No existe información disponible sobre el recurso solicitado",
		folio: messageid,
		info: "https://dev-api.com/info#404.isc-aml-gestion-empleados.4004",
        detalles: [
			"No existe información disponible sobre el recurso solicitado"
		]
    }
	context.setVariable("response.content", JSON.stringify(bodyResponse));
}
