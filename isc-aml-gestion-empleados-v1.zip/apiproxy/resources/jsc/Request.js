var proxy_pathsuffix = context.getVariable('proxy.pathsuffix');
var request_verb = context.getVariable('request.verb');
var messageid = context.getVariable("messageid");

var json_content = "";
var idEmpleado = "";

var bodyRequest;
var url = "";
var content_type = 'application/x-www-form-urlencoded';

if (proxy_pathsuffix == "/empleados" && request_verb == "POST") {
    requestCrearEmpleado();
} else if (proxy_pathsuffix.match("\/empleados\/.*") && request_verb == "GET") {
    content_type = "application/json";

    var path_folio_var_arr = proxy_pathsuffix.split("/");
    var path_folio_var = "";

    if(path_folio_var_arr[1] != undefined) {
        path_folio_var = path_folio_var_arr[1].trim();
    }
	
	if(path_folio_var == context.getVariable('request.formparam.idEmpleado')){
        bodyResponse200BusquedaExitosa();
    }
}

function requestCrearEmpleado(){
	
	idEmpleado = getRandomIntInclusive(1,20);
	
	if (json_content.nombreCompleto != undefined)
            context.setVariable('request.formparam.nombreCompleto', json_content.nombreCompleto);
		
	if (json_content.edad != undefined)
            context.setVariable('request.formparam.edad', json_content.edad);
		
	if (json_content.fechaNacimiento != undefined)
            context.setVariable('request.formparam.fechaNacimiento', json_content.fechaNacimiento);
		
	bodyResponse201CreacionExitosa(idEmpleado);
		
}

function getRandomIntInclusive(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1) + min);
}

function bodyResponse201CreacionExitosa(idParam) {
    context.setVariable('message.status.code', '201');
    context.setVariable('message.reason.phrase', 'ÉXITO');
    context.setVariable('request.formparam.idEmpleado', idEmpleado);
	
    bodyResponse = {
        mensaje: "Creacion Exitosa",
		folio: messageid,
        resultado: {
			idEmpleado: idEmpleado
		}
    }
	context.setVariable("response.content", JSON.stringify(bodyResponse));
}

function bodyResponse200BusquedaExitosa() {
	
    bodyResponse = {
        mensaje: "Busqueda Exitosa",
		folio: messageid,
        resultado: {
			empleado: context.getVariable('request.formparam.idEmpleado')
		}
    }
	context.setVariable("response.content", JSON.stringify(bodyResponse));
}